package com.example.num

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val convertbtn : Button = findViewById(R.id.convertBTN)

        convertbtn.setOnClickListener { convert() }
    }

    private fun convert()
    {
        val numinput : EditText = findViewById(R.id.NumberInput)
        val output : TextView = findViewById(R.id.output)

        val text = (numinput.text.toString().toInt()*1000).toString() + " meters"

        output.text = text
    }

}